'use client';

import { Button } from '@/components/ui/button';
import ZoneSummary from '@/components/oldv/zone-summary';
import { useState, useEffect } from 'react';
import type { loadData } from '@/types/simulation';

type MainContentProps = {
  triggerRefresh?: number;
};

export default function MainContent({ triggerRefresh }: MainContentProps) {
  const [zoneSummaryData, setZoneSummaryData] = useState<loadData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchZoneSummary = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('http://127.0.0.1:8000/station-bikes');
      if (!response.ok) throw new Error('Could not fetch summary');
      const data = await response.json();

      const numStations = Array.isArray(data.stations) ? data.stations.length : 0;
      const numBikes = Array.isArray(data.stations)
        ? data.stations.reduce((acc: number, s: { bikes: number }) => acc + (Number(s.bikes) || 0), 0)
        : 0;
      const city = data.city || '';

      setZoneSummaryData({ numBikes, numStations, city });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load summary');
      setZoneSummaryData(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchZoneSummary();
  }, [triggerRefresh]);

  if (isLoading) {
    return (
      <div className="flex flex-col h-full">
        <header className="flex items-center justify-between p-4 border-b bg-card">
          <h1 className="text-2xl font-bold font-headline">Gonzalo Bike Dashboard</h1>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <span className="animate-spin mr-2">🔄</span>
            <p>Loading summary...</p>
          </div>
        </main>
      </div>
    );
  }

  if (error || !zoneSummaryData) {
    return (
      <div className="flex flex-col h-full">
        <header className="flex items-center justify-between p-4 border-b bg-card">
          <h1 className="text-2xl font-bold font-headline">Gonzalo Bike Dashboard</h1>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center text-red-600">
            <p className="font-semibold">Error loading summary</p>
            <p className="text-sm">{error}</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center justify-between p-4 border-b bg-card">
        <h1 className="text-2xl font-bold font-headline">Gonzalo Bike Dashboard</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchZoneSummary}>
            <span className="mr-2">🔄</span>
            Refresh
          </Button>
        </div>
      </header>
      <main className="flex-1 p-6 space-y-6 overflow-y-auto">
        <ZoneSummary data={zoneSummaryData} />
      </main>
    </div>
  );
}

