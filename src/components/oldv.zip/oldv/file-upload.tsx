'use client';

import React, {useState} from 'react';
import {Label} from '@/components/ui/label';
import {Input} from '@/components/ui/input';
import {Button} from '@/components/ui/button';
import {Card, CardContent, CardHeader, CardTitle} from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import {Slider} from '@/components/ui/slider';

const API_BASE =
    process.env.NEXT_PUBLIC_API_BASE ?? 'http://localhost:8000';

export default function SimulateSidebar() {
    const [entrada, setEntrada] = useState('');
    const [salida, setSalida] = useState('');

    const [stressType, setStressType] = useState<'0' | '1'>('0');
    const [stress, setStress] = useState<number>(0);       // 0–100
    const [walkCostVal, setWalkCostVal] = useState<number>(1); // 0–5

    const [deltaMinutes, setDeltaMinutes] = useState<string>('15');
    const [diasText, setDiasText] = useState<string>(''); // ej: "0;1;2"

    const [apiBusy, setApiBusy] = useState(false);
    const [apiError, setApiError] = useState<string | null>(null);
    const [apiOk, setApiOk] = useState<string | null>(null);

    const handleSimulate = async () => {
        if (apiBusy) return;
        setApiBusy(true);
        setApiError(null);
        setApiOk(null);

        // parse days if provided
        let dias: number[] | null = null;
        if (diasText.trim().length > 0) {
            dias = diasText
                .split(';')
                .map(s => s.trim())
                .filter(s => s !== '')
                .map(Number)
                .filter(n => !Number.isNaN(n));
        }

        const body = {
            ruta_entrada: entrada || '',
            ruta_salida: salida || '',
            stress_type: Number(stressType),
            stress: stress,
            walk_cost: walkCostVal,
            delta: Number(deltaMinutes) || 15,
            dias: dias && dias.length > 0 ? dias : null,
        };

        try {
            const res = await fetch(`${API_BASE}/exe/simular-json`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(body),
            });
            if (!res.ok) {
                throw new Error(`HTTP ${res.status} ${res.statusText}`);
            }
            const json = await res.json();
            console.log('Simulación OK:', json);
            setApiOk('Simulación ejecutada correctamente');
        } catch (e: any) {
            setApiError(e?.message ?? 'Error inesperado');
        } finally {
            setApiBusy(false);
        }
    };

    return (
        <div className="flex flex-col h-full gap-3">
            <Card className="shadow-sm flex-1">
                <CardHeader className="py-2">
                    <CardTitle className="text-sm font-semibold">Simulación</CardTitle>
                </CardHeader>
                <CardContent className="pt-2 space-y-3">
                    {/* Paths */}
                    <div className="space-y-1">
                        <Label htmlFor="sim-entrada" className="text-xs">
                            Entrada simulador
                        </Label>
                        <Input
                            id="sim-entrada"
                            value={entrada}
                            onChange={e => setEntrada(e.target.value)}
                            placeholder="./Resultados_Simulador/Marzo_Reales"
                            className="h-8 text-xs"
                        />
                    </div>
                    <div className="space-y-1">
                        <Label htmlFor="sim-salida" className="text-xs">
                            Salida simulador
                        </Label>
                        <Input
                            id="sim-salida"
                            value={salida}
                            onChange={e => setSalida(e.target.value)}
                            placeholder="./Resultados_Simulador/Marzo_Reales_OUT"
                            className="h-8 text-xs"
                        />
                    </div>

                    {/* Stress + coste andar */}
                    <div className="space-y-3">
                        <div className="grid grid-cols-3 gap-2 items-center">
                            <div className="space-y-1">
                                <Label className="text-xs">Tipo stress</Label>
                                <Select
                                    value={stressType}
                                    onValueChange={val => setStressType(val as '0' | '1')}
                                >
                                    <SelectTrigger className="h-8 text-xs">
                                        <SelectValue/>
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="0">Ninguno</SelectItem>
                                        <SelectItem value="1">Por Bicicleta</SelectItem>
                                        <SelectItem value="2">Por Movimiento</SelectItem>
                                        <SelectItem value="3">Ambos</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="col-span-2 space-y-1">
                                <Label className="text-xs flex justify-between">
                                    <span>Stress </span>
                                    <span className="text-[10px] text-muted-foreground">
                    {stress}
                  </span>
                                </Label>
                                <Slider
                                    id="stress"
                                    value={[stress]}
                                    max={1}
                                    min={0}
                                    step={0.1}
                                    onValueChange={value => setStress(value[0])}
                                />
                            </div>
                        </div>

                        <div className="space-y-1">
                            <Label className="text-xs flex justify-between">
                                <span>Coste andar</span>
                                <span className="text-[10px] text-muted-foreground">
                  {walkCostVal.toFixed(1)}
                </span>
                            </Label>
                            <Slider
                                id="walkCost"
                                value={[walkCostVal]}
                                max={1}
                                min={0}
                                step={0.1}
                                onValueChange={value => setWalkCostVal(Number(value[0].toFixed(1)))}
                            />
                        </div>
                    </div>

                    {/* Delta y días */}
                    <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                            <Label className="text-xs">Delta (min)</Label>
                            <Input
                                className="h-8 text-xs"
                                value={deltaMinutes}
                                onChange={e => setDeltaMinutes(e.target.value)}
                                placeholder="15"
                            />
                        </div>
                        <div className="space-y-1">
                            <Label className="text-xs">Días a extraer (opcional)</Label>
                            <Input
                                className="h-8 text-xs"
                                value={diasText}
                                onChange={e => setDiasText(e.target.value)}
                                placeholder="Ej: 0;1;2"
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div className="flex items-center gap-2">
                <Button
                    size="sm"
                    onClick={handleSimulate}
                    disabled={apiBusy || !entrada || !salida}
                >
                    {apiBusy ? 'Simulando…' : 'Lanzar simulación'}
                </Button>
                {apiError && (
                    <span className="text-xs text-destructive">{apiError}</span>
                )}
                {apiOk && <span className="text-xs text-emerald-600">{apiOk}</span>}
            </div>
        </div>
    );
}
