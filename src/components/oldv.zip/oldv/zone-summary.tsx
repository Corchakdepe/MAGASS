'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bike, MapPin, Clock, AlertCircle } from 'lucide-react';
import type { SimulationSummaryData, loadData } from '@/types/simulation';

type loadSummaryData = {
  data: loadData;
};

export default function ZoneSummary({ data }: loadSummaryData) {
  // Safe helper function to format numbers
  const formatNumber = (value: number | undefined): string => {
    if (value === undefined || value === null || isNaN(value)) return '0.00';
    return value.toFixed(2);
  };

  const formatInt = (value: number | undefined): string => {
    if (value === undefined || value === null || isNaN(value)) return '0';
    return Math.round(value).toString();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold font-headline">Summary from initial loaded Data</h2>

      {/* Simulation Parameters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Number of Bikes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.numBikes}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Number Of Stations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.numStations}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">City</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.city}</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
